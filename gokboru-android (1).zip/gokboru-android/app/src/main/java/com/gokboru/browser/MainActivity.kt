package com.gokboru.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.speech.RecognizerIntent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

/** Tek bir sekme: kendi WebView'i ve son bilinen durumu. */
internal class BrowserTab(val webView: WebView, val isPrivate: Boolean = false) {
    var title: String = ""
    var url: String = ""
    var progress: Int = 100
    var loading: Boolean = false
    var favicon: Bitmap? = null
}

class MainActivity : AppCompatActivity() {

    private companion object {
        const val NEWTAB_URL = "file:///android_asset/newtab.html"
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"
        const val HOME_SCHEME = "gokboru"
    }

    private lateinit var prefs: Prefs
    private val tabs = mutableListOf<BrowserTab>()
    private var current: BrowserTab? = null
    private var desktopMode = false
    private var lastBackPress = 0L

    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var addressBar: EditText
    private lateinit var addressIcon: ImageView
    private lateinit var progressBar: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnReload: ImageButton
    private lateinit var tabCount: TextView

    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureOnBar = false

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val mobileUserAgent: String by lazy {
        // "; wv" ifadesini kaldırmak, birçok sitenin tarayıcıyı normal Chrome gibi görmesini sağlar.
        WebSettings.getDefaultUserAgent(this).replace("; wv", "")
    }

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            fileCallback?.onReceiveValue(uris)
            fileCallback = null
        }

    private val voiceLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) loadFromInput(spoken)
        }

    // ---------------------------------------------------------------------------------------
    // Yaşam döngüsü
    // ---------------------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        desktopMode = prefs.desktopDefault

        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        addressBar = findViewById(R.id.addressBar)
        addressIcon = findViewById(R.id.addressIcon)
        progressBar = findViewById(R.id.progressBar)
        webContainer = findViewById(R.id.webContainer)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnReload = findViewById(R.id.btnReload)
        tabCount = findViewById(R.id.tabCount)

        setupAddressBar()
        setupButtons()

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    handleBack()
                }
            }
        )

        val startUrl = intent?.dataString
        newTab(startUrl ?: NEWTAB_URL)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.dataString
        if (url != null) newTab(url)
    }

    override fun onResume() {
        super.onResume()
        current?.webView?.onResume()
    }

    override fun onPause() {
        current?.webView?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        for (tab in tabs) {
            webContainer.removeView(tab.webView)
            tab.webView.destroy()
        }
        tabs.clear()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------------------
    // Arayüz kurulumu
    // ---------------------------------------------------------------------------------------

    private fun setupAddressBar() {
        addressBar.setOnFocusChangeListener { view, hasFocus ->
            if (!hasFocus) {
                hideKeyboard(view)
                updateUi()
            }
        }
        addressBar.setOnEditorActionListener { _, actionId, event ->
            val enterPressed = event != null &&
                event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enterPressed) {
                loadFromInput(addressBar.text.toString())
                addressBar.clearFocus()
                current?.webView?.requestFocus()
                true
            } else {
                false
            }
        }
    }

    private fun setupButtons() {
        btnBack.setOnClickListener {
            val webView = current?.webView
            if (webView != null && webView.canGoBack()) webView.goBack()
        }
        btnForward.setOnClickListener {
            val webView = current?.webView
            if (webView != null && webView.canGoForward()) webView.goForward()
        }
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener {
            current?.webView?.loadUrl(NEWTAB_URL)
        }
        btnReload.setOnClickListener {
            val tab = current
            if (tab != null) {
                if (tab.loading) {
                    tab.webView.stopLoading()
                    tab.loading = false
                    updateUi()
                    updateProgress()
                } else {
                    tab.webView.reload()
                }
            }
        }
        findViewById<ImageButton>(R.id.btnTabs).setOnClickListener { showTabs() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { showMenu() }
        findViewById<ImageButton>(R.id.btnMic).setOnClickListener { startVoiceSearch() }
    }

    // ---------------------------------------------------------------------------------------
    // Sekme yönetimi
    // ---------------------------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String?, isPrivate: Boolean = false): BrowserTab {
        val webView = WebView(this)
        val tab = BrowserTab(webView, isPrivate)

        webView.setBackgroundColor(getColor(R.color.bg))
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.setSupportZoom(true)
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        if (isPrivate) {
            settings.cacheMode = WebSettings.LOAD_NO_CACHE
            @Suppress("DEPRECATION")
            settings.saveFormData = false
        }
        applyUserAgent(webView)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url
                if (uri?.scheme == HOME_SCHEME) return handleHomeAction(uri)
                return handleExternalScheme(uri)
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): android.webkit.WebResourceResponse? {
                if (request != null && prefs.adBlock && !request.isForMainFrame &&
                    AdBlocker.isBlocked(request.url?.host)
                ) {
                    return AdBlocker.emptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                tab.loading = true
                tab.progress = 5
                tab.url = url.orEmpty()
                if (tab === current) {
                    updateUi()
                    updateProgress()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.loading = false
                tab.progress = 100
                tab.url = url.orEmpty()
                tab.title = view?.title.orEmpty()
                if (!tab.isPrivate) prefs.addHistory(tab.title, tab.url)
                if (tab === current) {
                    updateUi()
                    updateProgress()
                }
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                tab.url = url.orEmpty()
                if (tab === current) updateUi()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.progress = newProgress
                if (tab === current) updateProgress()
            }

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                tab.favicon = icon
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title.orEmpty()
            }

            // target="_blank" ve window.open bağlantıları yeni sekmede açılır
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                val message = resultMsg ?: return false
                val transport = message.obj as? WebView.WebViewTransport ?: return false
                val created = newTab(null, tab.isPrivate)
                transport.webView = created.webView
                message.sendToTarget()
                return true
            }

            override fun onShowCustomView(
                view: View?,
                callback: WebChromeClient.CustomViewCallback?
            ) {
                if (view == null || customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(view)
                fullscreenContainer.visibility = View.VISIBLE
                setSystemBarsVisible(false)
            }

            override fun onHideCustomView() {
                exitFullscreen()
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                val chooserIntent = fileChooserParams?.createIntent() ?: return false
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileChooser.launch(chooserIntent)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        webView.setDownloadListener { downloadUrl, userAgent, contentDisposition, mimeType, _ ->
            startDownload(downloadUrl, userAgent, contentDisposition, mimeType)
        }

        tabs.add(tab)
        switchTo(tab)
        if (url != null) webView.loadUrl(normalizeInput(url))
        return tab
    }

    private fun switchTo(tab: BrowserTab) {
        val previous = current
        if (previous != null && previous !== tab) {
            previous.webView.onPause()
            webContainer.removeView(previous.webView)
        }
        current = tab
        (tab.webView.parent as? ViewGroup)?.removeView(tab.webView)
        webContainer.addView(
            tab.webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        tab.webView.onResume()
        updateUi()
        updateProgress()
    }

    private fun closeTab(tab: BrowserTab) {
        val index = tabs.indexOf(tab)
        if (index < 0) return
        tabs.removeAt(index)

        val wasCurrent = tab === current
        if (wasCurrent) current = null
        webContainer.removeView(tab.webView)
        tab.webView.stopLoading()
        tab.webView.destroy()

        if (tabs.isEmpty()) {
            newTab(NEWTAB_URL)
        } else if (wasCurrent) {
            switchTo(tabs[minOf(index, tabs.size - 1)])
        } else {
            updateUi()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Arayüzü güncelleme
    // ---------------------------------------------------------------------------------------

    private fun updateUi() {
        val tab = current ?: return
        val webView = tab.webView

        val canBack = webView.canGoBack()
        val canForward = webView.canGoForward()
        btnBack.isEnabled = canBack
        btnBack.alpha = if (canBack) 1f else 0.35f
        btnForward.isEnabled = canForward
        btnForward.alpha = if (canForward) 1f else 0.35f

        btnReload.setImageResource(if (tab.loading) R.drawable.ic_close else R.drawable.ic_refresh)
        tabCount.text = tabs.size.toString()

        val barColor = getColor(if (tab.isPrivate) R.color.private_bar else R.color.surface)
        topBar.setBackgroundColor(barColor)
        bottomBar.setBackgroundColor(barColor)
        if (tab.isPrivate && prefs.secureTabs) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }

        val secure = tab.url.startsWith("https://")
        addressIcon.setImageResource(if (secure) R.drawable.ic_lock else R.drawable.ic_search)

        if (!addressBar.hasFocus()) {
            addressBar.setText(displayUrl(tab.url))
        }
    }

    private fun updateProgress() {
        val tab = current ?: return
        val showBar = tab.loading && tab.progress < 100
        progressBar.visibility = if (showBar) View.VISIBLE else View.INVISIBLE
        progressBar.progress = tab.progress
    }

    private fun displayUrl(url: String): String {
        return if (url.isBlank() || url.startsWith(NEWTAB_URL)) "" else url
    }

    private fun tabLabel(tab: BrowserTab): String {
        if (tab.title.isNotBlank()) return tab.title
        val host = Uri.parse(tab.url).host
        return if (!host.isNullOrBlank()) host else getString(R.string.new_tab)
    }

    // ---------------------------------------------------------------------------------------
    // Sekme listesi ve menü
    // ---------------------------------------------------------------------------------------

    private fun showTabs() {
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_tabs, null)
        val title = sheet.findViewById<TextView>(R.id.sheetTitle)
        val list = sheet.findViewById<LinearLayout>(R.id.tabList)

        fun populate() {
            list.removeAllViews()
            title.text = getString(R.string.tabs_title, tabs.size)
            for (tab in tabs.toList()) {
                val row = layoutInflater.inflate(R.layout.item_tab, list, false)
                row.findViewById<TextView>(R.id.tabTitle).text =
                    (if (tab.isPrivate) "◐ " else "") + tabLabel(tab)
                val tabIcon = row.findViewById<ImageView>(R.id.tabIcon)
                val favicon = tab.favicon
                if (favicon != null && !tab.isPrivate) {
                    tabIcon.imageTintList = null
                    tabIcon.setImageBitmap(favicon)
                } else {
                    tabIcon.setImageResource(
                        if (tab.isPrivate) R.drawable.ic_incognito else R.drawable.ic_search
                    )
                    tabIcon.imageTintList =
                        android.content.res.ColorStateList.valueOf(getColor(R.color.gold))
                }
                val urlText = displayUrl(tab.url)
                row.findViewById<TextView>(R.id.tabUrl).text =
                    if (urlText.isEmpty()) getString(R.string.new_tab) else urlText
                if (tab === current) row.setBackgroundResource(R.drawable.bg_tab_active)
                row.setOnClickListener {
                    switchTo(tab)
                    dialog.dismiss()
                }
                row.findViewById<ImageButton>(R.id.tabClose).setOnClickListener {
                    closeTab(tab)
                    populate()
                }
                list.addView(row)
            }
        }

        populate()
        sheet.findViewById<View>(R.id.btnNewTab).setOnClickListener {
            newTab(NEWTAB_URL)
            dialog.dismiss()
            focusAddress()
        }

        sheet.findViewById<View>(R.id.btnNewPrivate).setOnClickListener {
            newTab(NEWTAB_URL, true)
            dialog.dismiss()
        }

        dialog.setContentView(sheet)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    private fun showMenu() {
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_list, null)
        sheet.findViewById<View>(R.id.listTitle).visibility = View.GONE
        val body = sheet.findViewById<LinearLayout>(R.id.listBody)

        val header = layoutInflater.inflate(R.layout.menu_header, body, false)
        header.findViewById<View>(R.id.menuSettings).setOnClickListener {
            dialog.dismiss()
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        body.addView(header)

        val tab = current
        val pageUrl = tab?.url.orEmpty()
        val realPage = pageUrl.isNotBlank() && !pageUrl.startsWith(NEWTAB_URL)

        addRow(body, R.drawable.ic_plus, getString(R.string.menu_new_tab), null, null) {
            dialog.dismiss()
            newTab(NEWTAB_URL)
            focusAddress()
        }
        addRow(body, R.drawable.ic_incognito, getString(R.string.menu_new_private), null, null) {
            dialog.dismiss()
            newTab(NEWTAB_URL, true)
        }
        if (realPage) {
            val fav = prefs.isFavorite(pageUrl)
            addRow(
                body, R.drawable.ic_star,
                getString(if (fav) R.string.favorite_removed else R.string.menu_add_favorite),
                null, null
            ) {
                dialog.dismiss()
                val added = prefs.toggleFavorite(tab?.title.orEmpty(), pageUrl)
                Toast.makeText(
                    this,
                    if (added) R.string.favorite_added else R.string.favorite_removed,
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        addRow(body, R.drawable.ic_star, getString(R.string.menu_favorites), null, null) {
            dialog.dismiss()
            showFavorites()
        }
        addRow(body, R.drawable.ic_history, getString(R.string.menu_history), null, null) {
            dialog.dismiss()
            showHistory()
        }
        addRow(body, R.drawable.ic_download, getString(R.string.menu_downloads), null, null) {
            dialog.dismiss()
            openDownloads()
        }
        addRow(body, R.drawable.ic_shield, getString(R.string.menu_adblock_short), null, prefs.adBlock) {
            prefs.adBlock = !prefs.adBlock
            current?.webView?.reload()
        }
        addRow(body, R.drawable.ic_settings, getString(R.string.menu_settings), null, null) {
            dialog.dismiss()
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val phoneRow = addRow(
            body, R.drawable.ic_home, getString(R.string.menu_phone_view), null, null,
            radioState = !desktopMode
        ) {
            dialog.dismiss()
            setDesktopMode(false)
        }
        val desktopRow = addRow(
            body, R.drawable.ic_desktop, getString(R.string.menu_desktop_view), null, null,
            radioState = desktopMode
        ) {
            dialog.dismiss()
            setDesktopMode(true)
        }
        if (phoneRow == desktopRow) return // asla olmaz; yalnızca değişkenlerin kullanıldığını belirtir

        if (realPage) {
            addRow(body, R.drawable.ic_share, getString(R.string.menu_share), null, null) {
                dialog.dismiss()
                shareCurrentPage()
            }
        }
        addRow(body, R.drawable.ic_close, getString(R.string.menu_exit), null, null) {
            dialog.dismiss()
            finishAffinity()
        }

        dialog.setContentView(sheet)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    private fun openDownloads() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            Toast.makeText(this, R.string.download_failed, Toast.LENGTH_SHORT).show()
        }
    }

    /** Menü/liste satırı ekler. switchState null değilse sağda anahtar gösterilir. */
    private fun addRow(
        container: LinearLayout,
        icon: Int,
        title: String,
        sub: String?,
        switchState: Boolean?,
        radioState: Boolean? = null,
        onClick: () -> Unit
    ): View {
        val row = layoutInflater.inflate(R.layout.item_row, container, false)
        row.findViewById<ImageView>(R.id.rowIcon).setImageResource(icon)
        row.findViewById<TextView>(R.id.rowTitle).text = title
        val subView = row.findViewById<TextView>(R.id.rowSub)
        if (!sub.isNullOrBlank()) {
            subView.text = sub
            subView.visibility = View.VISIBLE
        }
        val switch = row.findViewById<SwitchCompat>(R.id.rowSwitch)
        if (radioState != null) {
            val radio = row.findViewById<android.widget.RadioButton>(R.id.rowRadio)
            radio.visibility = View.VISIBLE
            radio.isChecked = radioState
            row.setOnClickListener { onClick() }
        } else if (switchState != null) {
            switch.visibility = View.VISIBLE
            switch.isChecked = switchState
            row.setOnClickListener {
                switch.isChecked = !switch.isChecked
                onClick()
            }
        } else {
            row.setOnClickListener { onClick() }
        }
        container.addView(row)
        return row
    }

    private fun showFavorites() {
        showEntries(R.string.menu_favorites, prefs.favorites(), R.string.empty_favorites, false)
    }

    private fun showHistory() {
        showEntries(R.string.menu_history, prefs.history(), R.string.empty_history, true)
    }

    private fun showEntries(titleRes: Int, entries: List<Prefs.Entry>, emptyRes: Int, isHistory: Boolean) {
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_list, null)
        sheet.findViewById<TextView>(R.id.listTitle).setText(titleRes)
        val body = sheet.findViewById<LinearLayout>(R.id.listBody)

        if (entries.isEmpty()) {
            val empty = TextView(this)
            empty.setText(emptyRes)
            empty.setTextColor(getColor(R.color.muted))
            empty.setPadding(16, 24, 16, 24)
            body.addView(empty)
        }
        if (isHistory && entries.isNotEmpty()) {
            addRow(body, R.drawable.ic_trash, getString(R.string.clear_history), null, null) {
                prefs.clearHistory()
                dialog.dismiss()
                Toast.makeText(this, R.string.history_cleared, Toast.LENGTH_SHORT).show()
            }
        }
        for (entry in entries) {
            val row = addRow(
                body,
                if (isHistory) R.drawable.ic_history else R.drawable.ic_star,
                entry.title,
                entry.url,
                null
            ) {
                dialog.dismiss()
                current?.webView?.loadUrl(entry.url)
            }
            if (!isHistory) {
                row.setOnLongClickListener {
                    prefs.toggleFavorite(entry.title, entry.url)
                    dialog.dismiss()
                    Toast.makeText(this, R.string.favorite_removed, Toast.LENGTH_SHORT).show()
                    true
                }
            }
        }

        dialog.setContentView(sheet)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    /** Ana sayfadaki gokboru:// bağlantıları. */
    private fun handleHomeAction(uri: Uri): Boolean {
        when (uri.host) {
            "favorites" -> showFavorites()
            "history" -> showHistory()
            "private" -> newTab(NEWTAB_URL, true)
            "tabs" -> showTabs()
            "mobile" -> setDesktopMode(false)
            "desktop" -> setDesktopMode(true)
            "adblock" -> {
                prefs.adBlock = !prefs.adBlock
                Toast.makeText(
                    this,
                    if (prefs.adBlock) R.string.adblock_on else R.string.adblock_off,
                    Toast.LENGTH_SHORT
                ).show()
            }
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
        }
        return true
    }

    private fun startVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_prompt))
        try {
            voiceLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.voice_unavailable, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Üst veya alt çubuk üzerinde kaydırma hareketleri:
     * sağa = geri, sola = ileri, yukarı = yeni sekme, aşağı = menü.
     */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureStartX = ev.rawX
                gestureStartY = ev.rawY
                gestureOnBar = prefs.gestures &&
                    (isOverView(topBar, ev) || isOverView(bottomBar, ev))
            }
            MotionEvent.ACTION_UP -> {
                if (gestureOnBar) {
                    gestureOnBar = false
                    val dx = ev.rawX - gestureStartX
                    val dy = ev.rawY - gestureStartY
                    val minDistance = resources.displayMetrics.density * 80f
                    val horizontal = Math.abs(dx) > minDistance && Math.abs(dy) < Math.abs(dx) / 2
                    val vertical = Math.abs(dy) > minDistance && Math.abs(dx) < Math.abs(dy) / 2
                    if (horizontal || vertical) {
                        ev.action = MotionEvent.ACTION_CANCEL
                        super.dispatchTouchEvent(ev)
                        val webView = current?.webView
                        if (horizontal) {
                            if (dx > 0) {
                                if (webView != null && webView.canGoBack()) webView.goBack()
                            } else {
                                if (webView != null && webView.canGoForward()) webView.goForward()
                            }
                        } else if (dy < 0) {
                            newTab(NEWTAB_URL)
                        } else {
                            showMenu()
                        }
                        return true
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> gestureOnBar = false
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun isOverView(view: View, ev: MotionEvent): Boolean {
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)
        return ev.rawX >= loc[0] && ev.rawX <= loc[0] + view.width &&
            ev.rawY >= loc[1] && ev.rawY <= loc[1] + view.height
    }

    private fun shareCurrentPage() {
        val url = current?.url.orEmpty()
        if (url.isBlank() || url.startsWith(NEWTAB_URL)) return
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, url)
        startActivity(Intent.createChooser(send, getString(R.string.share_via)))
    }

    private fun setDesktopMode(enabled: Boolean) {
        if (desktopMode == enabled) return
        desktopMode = enabled
        for (tab in tabs) applyUserAgent(tab.webView)
        val url = current?.url.orEmpty()
        if (url.isNotBlank() && !url.startsWith(NEWTAB_URL)) current?.webView?.reload()
    }

    private fun applyUserAgent(webView: WebView) {
        webView.settings.userAgentString = if (desktopMode) DESKTOP_UA else mobileUserAgent
    }

    private fun clearBrowsingData() {
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        prefs.clearHistory()
        for (tab in tabs) {
            tab.webView.clearCache(true)
            tab.webView.clearHistory()
        }
        Toast.makeText(this, R.string.data_cleared, Toast.LENGTH_SHORT).show()
        updateUi()
    }

    // ---------------------------------------------------------------------------------------
    // Gezinme yardımcıları
    // ---------------------------------------------------------------------------------------

    private fun loadFromInput(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        current?.webView?.loadUrl(normalizeInput(text))
    }

    private fun normalizeInput(input: String): String {
        val text = input.trim()
        if (text.isEmpty()) return NEWTAB_URL
        if (Regex("^(https?|file|about):", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
            return text
        }
        if (!text.contains(' ')) {
            val localHost = Regex("^localhost(:\\d+)?([/?#].*)?$", RegexOption.IGNORE_CASE)
            val ipAddress = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?([/?#].*)?$")
            val domain = Regex("^[\\w-]+(\\.[\\w-]+)+(:\\d+)?([/?#].*)?$")
            if (localHost.matches(text) || ipAddress.matches(text)) return "http://$text"
            if (domain.matches(text)) return "https://$text"
        }
        return prefs.searchUrl() + Uri.encode(text)
    }

    /** http/https dışındaki bağlantıları (tel:, mailto:, intent: ...) ilgili uygulamaya verir. */
    private fun handleExternalScheme(uri: Uri?): Boolean {
        val scheme = uri?.scheme?.lowercase() ?: return false
        val internalSchemes = listOf("http", "https", "file", "about", "javascript", "data", "blob")
        if (scheme in internalSchemes) return false
        try {
            val intent = if (scheme == "intent") {
                Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, uri)
            }
            intent.addCategory(Intent.CATEGORY_BROWSABLE)
            intent.component = null
            intent.selector = null
            startActivity(intent)
        } catch (e: Exception) {
            // Açacak uygulama yoksa sessizce vazgeç
        }
        return true
    }

    private fun startDownload(
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?
    ) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
            if (mimeType != null) request.setMimeType(mimeType)
            if (userAgent != null) request.addRequestHeader("User-Agent", userAgent)
            val cookies = CookieManager.getInstance().getCookie(url)
            if (cookies != null) request.addRequestHeader("Cookie", cookies)
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            request.setTitle(fileName)
            request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(
                this,
                getString(R.string.download_started, fileName),
                Toast.LENGTH_SHORT
            ).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.download_failed, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Geri tuşu, klavye, tam ekran
    // ---------------------------------------------------------------------------------------

    private fun handleBack() {
        if (customView != null) {
            exitFullscreen()
            return
        }
        val tab = current
        if (tab != null && tab.webView.canGoBack()) {
            tab.webView.goBack()
            return
        }
        if (tab != null && tabs.size > 1) {
            closeTab(tab)
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastBackPress < 2000) {
            finish()
        } else {
            lastBackPress = now
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show()
        }
    }

    private fun focusAddress() {
        addressBar.requestFocus()
        val manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        manager.showSoftInput(addressBar, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard(view: View) {
        val manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        manager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun exitFullscreen() {
        val view = customView ?: return
        val callback = customViewCallback
        customView = null
        customViewCallback = null
        fullscreenContainer.removeView(view)
        fullscreenContainer.visibility = View.GONE
        setSystemBarsVisible(true)
        callback?.onCustomViewHidden()
    }

    private fun setSystemBarsVisible(visible: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (visible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
}
