package com.gokboru.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Ayarlar, favoriler ve geçmiş burada saklanır (SharedPreferences). */
class Prefs(context: Context) {

    class Entry(val title: String, val url: String)

    private val sp = context.applicationContext
        .getSharedPreferences("gokboru", Context.MODE_PRIVATE)

    var adBlock: Boolean
        get() = sp.getBoolean("adblock", true)
        set(value) {
            sp.edit().putBoolean("adblock", value).apply()
        }

    var desktopDefault: Boolean
        get() = sp.getBoolean("desktop_default", false)
        set(value) {
            sp.edit().putBoolean("desktop_default", value).apply()
        }

    var gestures: Boolean
        get() = sp.getBoolean("gestures", true)
        set(value) {
            sp.edit().putBoolean("gestures", value).apply()
        }

    var secureTabs: Boolean
        get() = sp.getBoolean("secure_tabs", true)
        set(value) {
            sp.edit().putBoolean("secure_tabs", value).apply()
        }

    var searchIndex: Int
        get() = sp.getInt("search_engine", 0).coerceIn(0, ENGINES.size - 1)
        set(value) {
            sp.edit().putInt("search_engine", value).apply()
        }

    fun searchUrl(): String = ENGINES[searchIndex].second

    // --- Favoriler ---------------------------------------------------------------------

    fun favorites(): List<Entry> = readList("favorites")

    fun isFavorite(url: String): Boolean = favorites().any { it.url == url }

    /** Favoriyse çıkarır, değilse ekler. Eklendiyse true döner. */
    fun toggleFavorite(title: String, url: String): Boolean {
        val list = favorites().toMutableList()
        val existing = list.indexOfFirst { it.url == url }
        val added: Boolean
        if (existing >= 0) {
            list.removeAt(existing)
            added = false
        } else {
            list.add(0, Entry(title.ifBlank { url }, url))
            added = true
        }
        writeList("favorites", list)
        return added
    }

    // --- Geçmiş ------------------------------------------------------------------------

    fun history(): List<Entry> = readList("history")

    fun addHistory(title: String, url: String) {
        if (url.isBlank() || url.startsWith("file:") || url.startsWith("about:")) return
        val list = history().toMutableList()
        list.removeAll { it.url == url }
        list.add(0, Entry(title.ifBlank { url }, url))
        while (list.size > MAX_HISTORY) list.removeAt(list.size - 1)
        writeList("history", list)
    }

    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    // --- Yardımcılar -------------------------------------------------------------------

    private fun readList(key: String): List<Entry> {
        val raw = sp.getString(key, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            val result = ArrayList<Entry>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(Entry(obj.optString("t"), obj.optString("u")))
            }
            result
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeList(key: String, list: List<Entry>) {
        val array = JSONArray()
        for (entry in list) {
            val obj = JSONObject()
            obj.put("t", entry.title)
            obj.put("u", entry.url)
            array.put(obj)
        }
        sp.edit().putString(key, array.toString()).apply()
    }

    companion object {
        const val MAX_HISTORY = 200

        val ENGINES = listOf(
            "Google" to "https://www.google.com/search?q=",
            "DuckDuckGo" to "https://duckduckgo.com/?q=",
            "Bing" to "https://www.bing.com/search?q=",
            "Yandex" to "https://yandex.com.tr/search/?text="
        )
    }
}
